import os
import pandas as pd

class IdentityResolver:
    def __init__(self, identities_path='dataset/user_identities.csv', audit_log_path='dataset/user_audit_log.csv'):
        self.identities_path = identities_path
        self.audit_log_path = audit_log_path
        self.user_profiles = {}
        self.identifier_to_uid = {}
        self._load()

    def _load(self):
        if not os.path.exists(self.identities_path):
            raise FileNotFoundError(f"Identities file not found: {self.identities_path}")
            
        users_df = pd.read_csv(self.identities_path)
        for _, r in users_df.iterrows():
            uid = str(r['user_id']).strip()
            em = str(r['email']).strip().lower() if pd.notna(r['email']) else None
            ph = str(r['phone']).strip() if pd.notna(r['phone']) else None
            eh = str(r['email_hash']).strip() if pd.notna(r['email_hash']) else None
            nm = str(r['name']).strip() if pd.notna(r['name']) else None
            
            self.user_profiles[uid] = {
                'user_id': uid,
                'canonical_email': em,
                'canonical_phone': ph,
                'canonical_name': nm,
                'emails': {em} if em else set(),
                'phones': {ph} if ph else set(),
                'hashes': {eh} if eh else set(),
                'names': {nm} if nm else set()
            }
            if em:
                self.identifier_to_uid[em] = uid
            if ph:
                self.identifier_to_uid[ph] = uid
            if eh:
                self.identifier_to_uid[eh] = uid
            self.identifier_to_uid[uid.lower()] = uid

        if os.path.exists(self.audit_log_path):
            audit_df = pd.read_csv(self.audit_log_path)
            for _, r in audit_df.iterrows():
                uid = str(r['user_id']).strip()
                if uid in self.user_profiles:
                    field = r['field_name']
                    for val in [r['old_value'], r['new_value']]:
                        if pd.notna(val) and str(val).strip():
                            sval = str(val).strip()
                            if field == 'email':
                                self.user_profiles[uid]['emails'].add(sval.lower())
                                self.identifier_to_uid[sval.lower()] = uid
                            elif field == 'phone':
                                self.user_profiles[uid]['phones'].add(sval)
                                self.identifier_to_uid[sval] = uid
                            elif field == 'email_hash':
                                self.user_profiles[uid]['hashes'].add(sval)
                                self.identifier_to_uid[sval] = uid
                            elif field == 'name':
                                self.user_profiles[uid]['names'].add(sval)

    def resolve(self, identifier):
        if not identifier:
            return None
        s = str(identifier).strip()
        low = s.lower()
        if low in self.identifier_to_uid:
            uid = self.identifier_to_uid[low]
            return self.user_profiles[uid]
        if s in self.identifier_to_uid:
            uid = self.identifier_to_uid[s]
            return self.user_profiles[uid]
        return None

    def get_all_identifiers(self, user_profile):
        if not user_profile:
            return set()
        uid = user_profile['user_id']
        res = {uid.lower()}
        res.update(user_profile['emails'])
        res.update(user_profile['phones'])
        res.update(user_profile['hashes'])
        return res
