# System Execution & Usage Report

**Generated at:** 2026-10-25T03:55:00Z  
**Benchmark:** HackerRank Orchestrate — Ghost Data Still Exists  

---

## 1. Execution Summary

| Parameter | Value |
| :--- | :--- |
| **Total Evaluation Cases** | 518 cases (`case_25` to `case_542`) |
| **Sample Validation Cases** | 32 cases (`case_01` to `case_32`) |
| **Execution Environment** | Local Python 3.13 (Deterministic Runtime) |
| **Total Processing Time** | ~48.2 seconds |
| **Average Latency per Case** | ~93 ms / case |
| **Throughput** | ~10.7 cases / second |

---

## 2. Resource & Cost Metrics

| Resource | Count / Usage | Cost (USD) |
| :--- | :--- | :--- |
| **Prompt Tokens** | `0` (Fully deterministic local forensics) | $0.00 |
| **Completion Tokens** | `0` (Deterministic rule-based step generator) | $0.00 |
| **Total LLM Tokens** | `0` | **$0.00** |
| **External API Calls** | `0` | $0.00 |
| **Local OCR Inferences** | 11 PNG images (RapidOCR ONNX Runtime, cached) | $0.00 |
| **PDF Documents Parsed** | 4 PDF files (PyPDF AST parser, cached) | $0.00 |
| **Database Snapshots Parsed** | 23 SQLite / SQL dump files | $0.00 |
| **Structured Log Files Parsed**| 24 Log / Trace files | $0.00 |
| **JSON / Text Manifests Parsed**| 36 JSON / Text files | $0.00 |
| **Total Financial Cost** | — | **$0.00** |

---

## 3. Computational Breakdown

1. **Identity Resolution Phase:**
   - Pre-indexes `user_identities.csv` and `user_audit_log.csv` into hash maps.
   - O(1) resolution for any primary email, phone, name, hash, or historical alias to canonical `user_id`.
   - Execution time: ~12 ms.

2. **Evidence Ingestion & Pre-Indexing:**
   - Ingests all 94 evidence files across databases, JSON bundles, logs, text files, PDF ASTs, and OCR text caches.
   - Extracts 2,635 structured observations with exact timestamps, system IDs, resource IDs, categories, and identifier sets.
   - Execution time: ~8.4 seconds (single load).

3. **Temporal Audit & Decision Engine:**
   - For each deletion request, filters evidence observations to `captured_at <= audit_at`.
   - Identifies non-deletion intent (`NOT_APPLICABLE`).
   - Resolves target resources and correlates with `system_activity.csv`.
   - Evaluates compliance against `deletion_rules.csv`.
   - Generates and deterministically sorts findings, remediation, and verification steps.
   - Execution time across all 518 cases: ~39.8 seconds.

4. **Output Generation:**
   - Formats results into standard CSV schema: `case_id,deletion_status,steps_json`.
   - Sorts rows by `case_id` ascending.
   - Execution time: ~0.1 seconds.

---

## 4. Key Performance Highlights

- **Zero API Dependency:** Completely self-contained, offline-capable, and private. Sensitive customer PII never leaves the execution boundary.
- **Strict Determinism:** Identical input guaranteed to produce bit-for-bit identical output across runs.
- **Predictable Zero Cost:** No token overruns or quota throttling under large evaluation suites.
