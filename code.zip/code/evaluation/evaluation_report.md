# Deletion Audit Evaluation Report

Generated at: 2026-10-24T22:47:56.333210+00:00

## 1. Executive Summary
This report presents the rigorous evaluation of the Evidence-Driven AI Deletion Audit System against ground truth cases and synthetic edge cases.

## 2. Core Evaluation Metrics

| Metric | Value | Description |
| :--- | :--- | :--- |
| **Evaluated Cases** | `32` | Total evaluated cases with ground truth |
| **Case Status Accuracy** | `90.62%` | Exact status match (COMPLETE / INCOMPLETE / NOT_APPLICABLE) |
| **Step Precision** | `91.95%` | Precision of generated findings, remediation, verification steps |
| **Step Recall** | `82.90%` | Recall of ground-truth required audit steps |
| **Step F1 Score** | `87.19%` | Harmonic mean of step precision and recall |
| **Sequence Accuracy** | `43.75%` | Exact sequence and ordering compliance across phases |

## 3. Field-Level Accuracy Breakdown

| Field | Accuracy | Description |
| :--- | :--- | :--- |
| `phase` | `91.23%` | Exact match for `phase` attribute |
| `system_id` | `84.21%` | Exact match for `system_id` attribute |
| `resource_id` | `80.12%` | Exact match for `resource_id` attribute |
| `operation` | `80.70%` | Exact match for `operation` attribute |
| `state` | `83.04%` | Exact match for `state` attribute |
| `evidence_id` | `94.15%` | Exact match for `evidence_id` attribute |

## 4. Synthetic Edge Case Evaluations

### Edge Case 1: Historical Email Address Change Prior to Deletion
- **Scenario**: A user requests deletion using a legacy email address changed 3 months prior to deletion request intake.
- **Auditor Behavior**: The Identity Resolver follows the full history in `user_audit_log.csv`, identifies both historical and current email addresses and stable `user_id`, searches all evidence files across all identifiers, and successfully locates the active data flow and search index entries.
- **Verdict**: `INCOMPLETE` with ordered remediation and verification steps matching specification.

### Edge Case 2: Partial Workflow Failure with Conflicting Reported Status
- **Scenario**: The workflow engine reports `COMPLETE`, but the secondary database deletion job encountered a silent failure.
- **Auditor Behavior**: The auditor applies the primary principle: *Never trust reported_status or an operation result without checking available evidence*. Inspecting failover database replica snapshots reveals the profile record is still `PRESENT`.
- **Verdict**: Successfully overrides reported claim to `INCOMPLETE`, generating `REPORT_REMAINING_RECORD` on `account_service`.

### Edge Case 3: Re-creation of Deleted Personal Data via Secondary Synchronization
- **Scenario**: The primary user profile was deleted at 10:00 UTC, but an integration connector (`support_profile_sync`) remained active and recreated search index hits at 12:00 UTC prior to the audit timestamp.
- **Auditor Behavior**: The auditor reconstructs temporal state at `audit_at`. Finding active connector `REPORT_ACTIVE_DATA_FLOW` and remaining search index entry `REPORT_REMAINING_RECORD`, it prescribes `DISABLE_DATA_FLOW` before `DELETE_RECORD`.
- **Verdict**: `INCOMPLETE` with correct dependency-ordered remediation plan.

## 5. System Limitations & Failure Mode Analysis
1. **Unindexed Custom Formats**: If an evidence file format has no parser or valid OCR extraction, records inside it cannot be reconstructed.
2. **Identifiability Ambiguity**: If an analytics profile is stripped of all primary and secondary identifiers, attributing it without session logs is impossible under strict privacy guarantees.
3. **Timestamp Skew**: If log timestamps across microservices drift beyond reasonable network thresholds, event ordering relies on explicit causal traces (`trace_id`) rather than wall clock.
