import os
import sys
import argparse
import pandas as pd

# Add code directory to path
code_dir = os.path.dirname(os.path.abspath(__file__))
if code_dir not in sys.path:
    sys.path.insert(0, code_dir)

from deletion_auditor import DeletionAuditor

def main():
    parser = argparse.ArgumentParser(description="Evidence-Driven AI Deletion Audit System")
    parser.add_argument(
        '--dataset',
        type=str,
        default='dataset',
        help="Path to dataset directory (default: dataset)"
    )
    parser.add_argument(
        '--requests',
        type=str,
        default='dataset/deletion_requests.csv',
        help="Path to deletion requests CSV (default: dataset/deletion_requests.csv)"
    )
    parser.add_argument(
        '--output',
        type=str,
        default='output.csv',
        help="Path to output CSV (default: output.csv)"
    )
    
    args = parser.parse_args()
    
    print(f"Initializing Deletion Auditor from dataset: {args.dataset}...")
    auditor = DeletionAuditor(dataset_dir=args.dataset)
    
    print(f"Reading requests from: {args.requests}...")
    requests_df = pd.read_csv(args.requests)
    
    results = []
    total_cases = len(requests_df)
    print(f"Auditing {total_cases} cases...")
    
    for idx, row in requests_df.iterrows():
        case_id = row['case_id']
        email = row.get('email', '')
        req_at = row.get('requested_at', '')
        rep_status = row.get('reported_status', None)
        rep_at = row.get('reported_at', '')
        aud_at = row.get('audit_at', '')
        req_text = row.get('request_text', '')
        
        audit_res = auditor.audit_case(
            case_id=case_id,
            email=email,
            requested_at=req_at,
            reported_at=rep_at,
            audit_at=aud_at,
            request_text=req_text,
            reported_status=rep_status
        )
        results.append(audit_res)
        
        if (idx + 1) % 50 == 0 or (idx + 1) == total_cases:
            print(f"Processed {idx + 1}/{total_cases} cases...")

    # Build output DataFrame and enforce sorting by case_id
    out_df = pd.DataFrame(results)
    
    # Sort by case_id ascending (handling numeric case numbers properly)
    def case_sort_key(cid):
        s = str(cid)
        if s.startswith('case_') and s[5:].isdigit():
            return (0, int(s[5:]))
        return (1, s)
        
    out_df['sort_key'] = out_df['case_id'].apply(case_sort_key)
    out_df = out_df.sort_values(by='sort_key').drop(columns=['sort_key'])
    
    # Verify schema
    expected_cols = ['case_id', 'deletion_status', 'steps_json']
    out_df = out_df[expected_cols]
    
    out_df.to_csv(args.output, index=False)
    print(f"Successfully generated audit results at: {args.output} ({len(out_df)} rows).")

if __name__ == '__main__':
    main()
