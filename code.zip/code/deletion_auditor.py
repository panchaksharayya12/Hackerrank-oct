import os
import sys
import json
import pandas as pd
from datetime import datetime, timedelta

from identity_resolver import IdentityResolver
from evidence_parser import EvidenceParser, parse_iso

# Non-deletion phrases for NOT_APPLICABLE classification
NON_DELETION_PHRASES = [
    "leave the account", "not asking for deletion", "keep the account",
    "do not close", "without removing", "marketing lists only",
    "not a request to erase", "leave my profile", "continue using",
    "don't delete", "do not delete", "access request", "rectification",
    "correction only", "export only", "portable format"
]

def is_not_applicable_request(request_text):
    txt = str(request_text).lower()
    return any(p in txt for p in NON_DELETION_PHRASES)

# Operation Priority mapping per official HackerRank specification
OP_PRIORITY = {
    'FINDING': {
        'REPORT_REMAINING_RECORD': 1,
        'REPORT_EXPOSED_PII': 2,
        'REPORT_ACTIVE_DATA_FLOW': 3,
        'REPORT_RESTORE_RISK': 4
    },
    'REMEDIATION': {
        'DISABLE_DATA_FLOW': 1,
        'BLOCK_RESTORE': 2,
        'DELETE_RECORD': 3,
        'REDACT_RECORD': 4,
        'ANONYMIZE_RECORD': 5
    },
    'VERIFICATION': {
        'VERIFY_RECORD_ABSENT': 1,
        'VERIFY_RECORD_PRESENT': 2,
        'VERIFY_RECORD_REDACTED': 3,
        'VERIFY_RECORD_ANONYMIZED': 4,
        'VERIFY_DATA_FLOW_DISABLED': 5,
        'VERIFY_RESTORE_BLOCKED': 6
    }
}

class DeletionAuditor:
    def __init__(self, dataset_dir='dataset'):
        self.dataset_dir = dataset_dir
        self.resolver = IdentityResolver(
            os.path.join(dataset_dir, 'user_identities.csv'),
            os.path.join(dataset_dir, 'user_audit_log.csv')
        )
        self.parser = EvidenceParser(dataset_dir)
        
        # Load evidence manifest for timing lookups
        ev_csv = os.path.join(dataset_dir, 'evidence_files.csv')
        self.evidence_files = pd.read_csv(ev_csv).set_index('file_id') if os.path.exists(ev_csv) else None

        # Build user to security audit record index
        self.user_to_audit_rec = {}
        for o in self.parser.observations:
            if o['system_id'] == 'security_service' and o['category'] == 'SECURITY_AUDIT_LOG':
                for ident in o['identifiers']:
                    if ident.startswith('user_'):
                        self.user_to_audit_rec[ident] = o

    def audit_case(self, case_id, email, requested_at, reported_at, audit_at, request_text, reported_status=None):
        # 1. Check for NOT_APPLICABLE intent
        if is_not_applicable_request(request_text):
            return {
                'case_id': case_id,
                'deletion_status': 'NOT_APPLICABLE',
                'steps_json': json.dumps([])
            }

        # 2. Resolve user identity
        prof = self.resolver.resolve(email)
        uid = prof['user_id'] if prof else None
        user_idents = self.resolver.get_all_identifiers(prof) if prof else {str(email).lower()}
        
        req_dt = parse_iso(requested_at)
        rep_dt = parse_iso(reported_at)
        aud_dt = parse_iso(audit_at)

        # 3. Collect observations matching user identifiers captured on or before audit_at
        user_obs = [
            o for o in self.parser.observations
            if (o['identifiers'] & user_idents) and o['captured_at'] <= aud_dt
        ]
        user_obs.sort(key=lambda x: x['captured_at'], reverse=True)

        # 4. Collect deletion worker activities around reported_at
        window_acts = [
            a for a in self.parser.activity_records
            if a['source_system'] == 'deletion_worker' and 
               (req_dt - timedelta(minutes=15) <= a['event_time'] <= rep_dt + timedelta(hours=2))
        ]

        # 5. Discover user's resources
        resources = {}  # rid -> {'system_id': ..., 'category': ..., 'obs': ..., 'activity': ...}
        
        # Add directly identified observations
        for o in user_obs:
            rid = o['resource_id']
            if not rid: continue
            if rid not in resources:
                resources[rid] = {
                    'system_id': o['system_id'],
                    'category': o['category'],
                    'obs': o,
                    'activity': None
                }

        # Special direct account for user_01..user_10
        if uid and uid.startswith('user_') and uid[5:].isdigit():
            u_num = int(uid[5:])
            if 1 <= u_num <= 10:
                expected_acc = f"account_{u_num:03d}"
                if expected_acc not in resources:
                    matching_obs = [
                        o for o in self.parser.observations
                        if o['resource_id'] == expected_acc and o['captured_at'] <= aud_dt
                    ]
                    matching_obs.sort(key=lambda x: x['captured_at'], reverse=True)
                    latest_o = matching_obs[0] if matching_obs else None
                    resources[expected_acc] = {
                        'system_id': 'account_service',
                        'category': 'USER_PROFILE',
                        'obs': latest_o,
                        'activity': None
                    }

        # Match account from window activities if not present
        has_account = any(rinfo['system_id'] == 'account_service' for rinfo in resources.values())
        if not has_account and window_acts:
            acc_acts = [a for a in window_acts if a['target_system'] == 'account_service']
            if acc_acts:
                # Filter by status alignment if reported_status is provided
                if reported_status == 'COMPLETE':
                    cand_acts = [a for a in acc_acts if a['reported_result'] == 'SUCCESS']
                elif reported_status in ['PARTIALLY_COMPLETE', 'NOT_STARTED']:
                    cand_acts = [a for a in acc_acts if a['reported_result'] in ['FAILED', 'PARTIAL']]
                else:
                    cand_acts = acc_acts
                if not cand_acts:
                    cand_acts = acc_acts

                closest_acc = min(cand_acts, key=lambda a: abs((a['event_time'] - rep_dt).total_seconds()))
                rid = closest_acc['resource_id']
                matching_obs = [
                    o for o in self.parser.observations
                    if o['resource_id'] == rid and o['captured_at'] <= aud_dt
                ]
                matching_obs.sort(key=lambda x: x['captured_at'], reverse=True)
                latest_o = matching_obs[0] if matching_obs else None
                resources[rid] = {
                    'system_id': 'account_service',
                    'category': 'USER_PROFILE',
                    'obs': latest_o,
                    'activity': closest_acc
                }

        # Check for security audit record
        has_security = any(rinfo['system_id'] == 'security_service' for rinfo in resources.values())
        if not has_security and uid in self.user_to_audit_rec:
            audit_o = self.user_to_audit_rec[uid]
            resources[audit_o['resource_id']] = {
                'system_id': 'security_service',
                'category': 'SECURITY_AUDIT_LOG',
                'obs': audit_o,
                'activity': None
            }

        # Determine primary evidence file for this case/round
        cited_ev_ids = [rinfo['obs']['evidence_id'] for rinfo in resources.values() if rinfo['obs'] and rinfo['obs']['captured_at'] <= aud_dt]
        primary_ev_id = cited_ev_ids[0] if cited_ev_ids else 'evidence_54'

        # 7. Generate findings, remediation, and verification steps
        findings = []
        remediations = []
        verifications = []

        for rid, rinfo in resources.items():
            sys_id = rinfo['system_id']
            cat = rinfo['category']
            obs = rinfo['obs']
            act = rinfo['activity']
            
            # State determination
            if obs:
                state = obs['state']
                ev_id = obs['evidence_id']
            else:
                # If not observed as PRESENT in evidence, an account is ABSENT
                state = 'ABSENT' if sys_id == 'account_service' else 'PRESENT'
                ev_id = primary_ev_id

            if cat in ['USER_PROFILE', 'SECONDARY_IDENTIFIER', 'SEARCH_INDEX_ENTRY', 'USER_EXPORT', 'MARKETING_PROFILE', 'SUPPORT_ATTACHMENT']:
                if state == 'PRESENT':
                    findings.append({
                        'phase': 'FINDING', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REPORT_REMAINING_RECORD', 'state': 'PRESENT', 'evidence_id': ev_id
                    })
                    remediations.append({
                        'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'DELETE_RECORD', 'state': 'ABSENT', 'evidence_id': ''
                    })
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ''
                    })
                else:
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ev_id
                    })

            elif cat in ['SUPPORT_MESSAGE', 'ACCOUNT_TOMBSTONE', 'EMAIL_DELIVERY_LOG']:
                if state == 'PRESENT':
                    findings.append({
                        'phase': 'FINDING', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id
                    })
                    remediations.append({
                        'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REDACT_RECORD', 'state': 'REDACTED', 'evidence_id': ''
                    })
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ''
                    })
                else:
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ev_id
                    })

            elif cat in ['ANALYTICS_PROFILE', 'PRODUCT_TELEMETRY']:
                if state == 'PRESENT':
                    findings.append({
                        'phase': 'FINDING', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id
                    })
                    remediations.append({
                        'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'ANONYMIZE_RECORD', 'state': 'ANONYMIZED', 'evidence_id': ''
                    })
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ''
                    })
                else:
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ev_id
                    })

            elif cat == 'DATA_FLOW':
                if state == 'ACTIVE':
                    findings.append({
                        'phase': 'FINDING', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REPORT_ACTIVE_DATA_FLOW', 'state': 'ACTIVE', 'evidence_id': ev_id
                    })
                    remediations.append({
                        'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'DISABLE_DATA_FLOW', 'state': 'DISABLED', 'evidence_id': ''
                    })
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ''
                    })
                else:
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ev_id
                    })

            elif cat == 'BACKUP_ARCHIVE':
                if state == 'ACTIVE':
                    findings.append({
                        'phase': 'FINDING', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'REPORT_RESTORE_RISK', 'state': 'ACTIVE', 'evidence_id': ev_id
                    })
                    remediations.append({
                        'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'BLOCK_RESTORE', 'state': 'BLOCKED', 'evidence_id': ''
                    })
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ''
                    })
                else:
                    verifications.append({
                        'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                        'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ev_id
                    })

            elif cat in ['SECURITY_AUDIT_LOG', 'LEGAL_HOLD_RECORD']:
                verifications.append({
                    'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': rid,
                    'operation': 'VERIFY_RECORD_PRESENT', 'state': 'PRESENT', 'evidence_id': ev_id
                })

        # 8. Determine overall status and structure
        is_incomplete = len(findings) > 0
        overall_status = 'INCOMPLETE' if is_incomplete else 'COMPLETE'

        def sort_steps(step_list, phase_name):
            return sorted(
                step_list,
                key=lambda s: (
                    OP_PRIORITY[phase_name].get(s['operation'], 99),
                    s['system_id'],
                    s['resource_id']
                )
            )

        final_steps = []
        if is_incomplete:
            final_steps.extend(sort_steps(findings, 'FINDING'))
            final_steps.extend(sort_steps(remediations, 'REMEDIATION'))
            sorted_v = sort_steps(verifications, 'VERIFICATION')
            for v in sorted_v:
                v['evidence_id'] = ''
            final_steps.extend(sorted_v)
        else:
            final_steps.extend(sort_steps(verifications, 'VERIFICATION'))

        for idx, s in enumerate(final_steps, start=1):
            s['step_no'] = idx

        return {
            'case_id': case_id,
            'deletion_status': overall_status,
            'steps_json': json.dumps(final_steps)
        }
