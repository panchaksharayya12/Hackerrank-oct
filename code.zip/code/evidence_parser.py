import os
import sys
import re
import json
import sqlite3
import pandas as pd
from datetime import datetime

def parse_iso(s):
    if not s or pd.isna(s):
        return datetime.min
    return datetime.fromisoformat(str(s).replace('Z', '+00:00'))

class EvidenceParser:
    def __init__(self, dataset_dir='dataset'):
        self.dataset_dir = dataset_dir
        self.evidence_files_path = os.path.join(dataset_dir, 'evidence_files.csv')
        self.activity_path = os.path.join(dataset_dir, 'system_activity.csv')
        self.ocr_cache_path = os.path.join(dataset_dir, 'evidence', 'images_ocr_cache.json')
        self.pdf_cache_path = os.path.join(dataset_dir, 'evidence', 'pdfs_cache.json')
        
        self.observations = []
        self.activity_records = []
        self.resource_to_activities = {}
        self._load()

    def _load(self):
        # 1. Load OCR & PDF caches if available
        ocr_cache = {}
        if os.path.exists(self.ocr_cache_path):
            with open(self.ocr_cache_path, 'r', encoding='utf-8') as fp:
                ocr_cache = json.load(fp)
                
        pdf_cache = {}
        if os.path.exists(self.pdf_cache_path):
            with open(self.pdf_cache_path, 'r', encoding='utf-8') as fp:
                pdf_cache = json.load(fp)

        # 2. Load system activity
        if os.path.exists(self.activity_path):
            act_df = pd.read_csv(self.activity_path)
            for _, r in act_df.iterrows():
                dt = parse_iso(r['event_time'])
                rid = str(r['resource_id']).strip() if pd.notna(r['resource_id']) else None
                rec = {
                    'activity_id': r['activity_id'],
                    'event_time': dt,
                    'event_type': r['event_type'],
                    'source_system': r['source_system'],
                    'target_system': r['target_system'],
                    'resource_id': rid,
                    'reported_result': r['reported_result'],
                    'details': str(r['details'])
                }
                self.activity_records.append(rec)
                if rid:
                    self.resource_to_activities.setdefault(rid, []).append(rec)

        # 3. Load evidence files
        if not os.path.exists(self.evidence_files_path):
            return

        evidence_df = pd.read_csv(self.evidence_files_path)
        for _, r in evidence_df.iterrows():
            fid = r['file_id']
            fpath = os.path.join(self.dataset_dir, r['file_path'])
            origin = r['origin']
            cap_dt = parse_iso(r['captured_at'])
            if not os.path.exists(fpath):
                continue
            ext = os.path.splitext(fpath)[1].lower()

            # A. Service resource export (JSON)
            if 'service_resource_export' in origin or 'service_resource_export' in fpath:
                with open(fpath, 'r', encoding='utf-8') as fp:
                    data = json.load(fp)
                    exports = data.get('service_exports', {})
                    # account_service
                    for item in exports.get('account_service', {}).get('profile_lookups', []):
                        rid = item.get('resource_id')
                        prof = item.get('profile')
                        status = item.get('status_code')
                        st = 'ABSENT' if (status == 404 or prof is None) else 'PRESENT'
                        idents = set()
                        if prof:
                            for k in ['customer_reference', 'email', 'phone', 'email_hash']:
                                if prof.get(k): idents.add(str(prof[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'account_service',
                            'resource_id': rid, 'category': 'USER_PROFILE', 'state': st, 'identifiers': idents
                        })
                    # analytics_platform
                    for item in exports.get('analytics_platform', {}).get('profiles', []):
                        rid = item.get('resource_id')
                        has_pii = any(item.get(k) for k in ['customer_reference', 'email', 'phone', 'email_hash'])
                        st = 'PRESENT' if has_pii else 'ANONYMIZED'
                        idents = set()
                        for k in ['customer_reference', 'email', 'phone', 'email_hash']:
                            if item.get(k): idents.add(str(item[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'analytics_platform',
                            'resource_id': rid, 'category': 'ANALYTICS_PROFILE', 'state': st, 'identifiers': idents
                        })
                    # backup_service
                    for item in exports.get('backup_service', {}).get('restore_entries', []):
                        rid = item.get('resource_id')
                        allowed = item.get('restore_allowed', False)
                        st = 'ACTIVE' if allowed else 'BLOCKED'
                        idents = set()
                        for k in ['customer_reference', 'customer_email']:
                            if item.get(k): idents.add(str(item[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'backup_service',
                            'resource_id': rid, 'category': 'BACKUP_ARCHIVE', 'state': st, 'identifiers': idents
                        })
                    # export_service
                    for item in exports.get('export_service', {}).get('exports', []):
                        rid = item.get('resource_id')
                        idents = set()
                        for k in ['customer_reference', 'owner_email', 'owner_phone']:
                            if item.get(k): idents.add(str(item[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'export_service',
                            'resource_id': rid, 'category': 'USER_EXPORT', 'state': 'PRESENT', 'identifiers': idents
                        })
                    # integration_service
                    for item in exports.get('integration_service', {}).get('connectors', []):
                        rid = item.get('resource_id')
                        enabled = item.get('enabled', False)
                        st = 'ACTIVE' if enabled else 'DISABLED'
                        idents = set()
                        for k in ['customer_reference', 'customer_email']:
                            if item.get(k): idents.add(str(item[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'integration_service',
                            'resource_id': rid, 'category': 'DATA_FLOW', 'state': st, 'identifiers': idents
                        })
                    # search_service
                    for item in exports.get('search_service', {}).get('index_queries', []):
                        rid = item.get('resource_id')
                        hits = item.get('hits', {})
                        total = hits.get('total', 0)
                        st = 'PRESENT' if total > 0 else 'ABSENT'
                        idents = set()
                        for doc in hits.get('documents', []):
                            for k in ['customer_reference', 'email', 'phone', 'email_hash']:
                                if doc.get(k): idents.add(str(doc[k]).lower())
                        if item.get('query'): idents.add(str(item['query']).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'search_service',
                            'resource_id': rid, 'category': 'SEARCH_INDEX_ENTRY', 'state': st, 'identifiers': idents
                        })
                    # security_service
                    for item in exports.get('security_service', {}).get('audit_records', []):
                        rid = item.get('resource_id')
                        idents = set()
                        if item.get('subject_reference'): idents.add(str(item['subject_reference']).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'security_service',
                            'resource_id': rid, 'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT', 'identifiers': idents
                        })
                    # support_platform
                    for item in exports.get('support_platform', {}).get('tickets', []):
                        rid = item.get('resource_id')
                        has_pii = any(item.get(k) for k in ['requester_email', 'requester_name', 'requester_phone'])
                        st = 'PRESENT' if has_pii else 'REDACTED'
                        idents = set()
                        for k in ['customer_reference', 'requester_email', 'requester_phone']:
                            if item.get(k): idents.add(str(item[k]).lower())
                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'support_platform',
                            'resource_id': rid, 'category': 'SUPPORT_MESSAGE', 'state': st, 'identifiers': idents
                        })

            # B. Snapshot bundle (JSON)
            elif 'snapshot_bundle' in fpath or origin == 'records_assurance_snapshot_bundle':
                with open(fpath, 'r', encoding='utf-8') as fp:
                    data = json.load(fp)
                    for snap in data.get('snapshots', []):
                        dstore = snap.get('data_store')
                        for rec in snap.get('records', []):
                            rid = rec.get('resource_id')
                            idents = set()
                            for k in ['customer_reference', 'user_id', 'subject_reference', 'email', 'phone', 'email_hash']:
                                if rec.get(k): idents.add(str(rec[k]).lower())
                            if 'document' in rec and isinstance(rec['document'], dict):
                                for k in ['customer_reference', 'email', 'phone', 'email_hash']:
                                    if rec['document'].get(k): idents.add(str(rec['document'][k]).lower())
                            
                            if dstore == 'account_service':
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'account_service',
                                    'resource_id': rid, 'category': 'USER_PROFILE', 'state': 'PRESENT', 'identifiers': idents
                                })
                            elif dstore == 'search_service':
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'search_service',
                                    'resource_id': rid, 'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT', 'identifiers': idents
                                })
                            elif dstore == 'analytics_platform':
                                has_pii = any(rec.get(k) for k in ['user_id', 'email', 'phone', 'email_hash'])
                                st = 'PRESENT' if has_pii else 'ANONYMIZED'
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'analytics_platform',
                                    'resource_id': rid, 'category': 'ANALYTICS_PROFILE', 'state': st, 'identifiers': idents
                                })
                            elif dstore == 'backup_service':
                                allowed = rec.get('restore_allowed', False)
                                st = 'ACTIVE' if allowed else 'BLOCKED'
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'backup_service',
                                    'resource_id': rid, 'category': 'BACKUP_ARCHIVE', 'state': st, 'identifiers': idents
                                })
                            elif dstore == 'export_service':
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'export_service',
                                    'resource_id': rid, 'category': 'USER_EXPORT', 'state': 'PRESENT', 'identifiers': idents
                                })
                            elif dstore == 'integration_service':
                                enabled = rec.get('enabled', False)
                                st = 'ACTIVE' if enabled else 'DISABLED'
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'integration_service',
                                    'resource_id': rid, 'category': 'DATA_FLOW', 'state': st, 'identifiers': idents
                                })
                            elif dstore == 'security_service':
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'security_service',
                                    'resource_id': rid, 'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT', 'identifiers': idents
                                })
                            elif dstore == 'support_platform':
                                msg = str(rec.get('message_text', ''))
                                st = 'REDACTED' if '[REDACTED]' in msg else 'PRESENT'
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'support_platform',
                                    'resource_id': rid, 'category': 'SUPPORT_MESSAGE', 'state': st, 'identifiers': idents
                                })
                            elif dstore == 'identity_service':
                                em = rec.get('email')
                                st = 'REDACTED' if (not em or em == '[REDACTED]') else 'PRESENT'
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'identity_service',
                                    'resource_id': rid, 'category': 'ACCOUNT_TOMBSTONE', 'state': st, 'identifiers': idents
                                })

            # C. Handover (TXT)
            elif ext == '.txt' and 'handover' in fpath:
                with open(fpath, 'r', encoding='utf-8') as fp:
                    for line in fp:
                        line = line.strip()
                        if line.startswith('-'):
                            parts = [p.strip() for p in line[1:].split('|')]
                            if len(parts) >= 6:
                                ts_str, sys_id, rid, cat, status_str, ident = parts[:6]
                                idents = {ident.lower()}
                                st_map = {
                                    'NOT_FOUND': 'ABSENT', 'FOUND': 'PRESENT', 'IDENTIFIABLE': 'PRESENT',
                                    'ANONYMIZED': 'ANONYMIZED', 'REDACTED': 'REDACTED',
                                    'ACTIVE': 'ACTIVE', 'DISABLED': 'DISABLED', 'BLOCKED': 'BLOCKED'
                                }
                                st = st_map.get(status_str, 'PRESENT')
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                                    'resource_id': rid, 'category': cat, 'state': st, 'identifiers': idents
                                })

            # D. Other JSON files
            elif ext == '.json':
                with open(fpath, 'r', encoding='utf-8') as fp:
                    data = json.load(fp)
                    if 'customer_analytics_report' in fpath:
                        for rec in data.get('records', []):
                            rid = rec.get('resource_id')
                            idents = set()
                            for k in ['user_id', 'email', 'phone', 'email_hash']:
                                if rec.get(k): idents.add(str(rec[k]).lower())
                            st = 'PRESENT' if idents else 'ANONYMIZED'
                            self.observations.append({
                                'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'analytics_platform',
                                'resource_id': rid, 'category': 'ANALYTICS_PROFILE', 'state': st, 'identifiers': idents
                            })
                    elif 'customer_export_jobs' in fpath or 'export_manifest' in fpath:
                        recs = data.get('jobs', data.get('exports', data.get('records', [])))
                        if isinstance(data, list): recs = data
                        for rec in recs:
                            rid = rec.get('resource_id') or rec.get('job_id')
                            idents = set()
                            for k in ['customer_reference', 'user_id', 'owner_email', 'email']:
                                if rec.get(k): idents.add(str(rec[k]).lower())
                            self.observations.append({
                                'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'export_service',
                                'resource_id': rid, 'category': 'USER_EXPORT', 'state': 'PRESENT', 'identifiers': idents
                            })
                    elif 'connector_configurations' in fpath:
                        for rec in data.get('connectors', data.get('records', [])):
                            rid = rec.get('resource_id')
                            enabled = rec.get('enabled', False)
                            idents = set()
                            for k in ['customer_reference', 'customer_email', 'user_id']:
                                if rec.get(k): idents.add(str(rec[k]).lower())
                            self.observations.append({
                                'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'integration_service',
                                'resource_id': rid, 'category': 'DATA_FLOW', 'state': 'ACTIVE' if enabled else 'DISABLED', 'identifiers': idents
                            })
                    elif 'security_audit_ledger' in fpath:
                        for rec in data.get('ledger', data.get('records', [])):
                            rid = rec.get('resource_id') or rec.get('record_id')
                            idents = set()
                            for k in ['subject_reference', 'user_id']:
                                if rec.get(k): idents.add(str(rec[k]).lower())
                            self.observations.append({
                                'evidence_id': fid, 'captured_at': cap_dt, 'system_id': 'security_service',
                                'resource_id': rid, 'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT', 'identifiers': idents
                            })

            # E. SQL files
            elif ext == '.sql':
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                    sql_text = fp.read()
                conn = sqlite3.connect(':memory:')
                try:
                    conn.executescript(sql_text)
                    cursor = conn.cursor()
                    tables = [row[0] for row in cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
                    for tbl in tables:
                        if tbl == 'snapshot_scope':
                            continue
                        col_names = [d[1] for d in cursor.execute(f"PRAGMA table_info({tbl});").fetchall()]
                        rows = cursor.execute(f"SELECT * FROM {tbl};").fetchall()
                        for row_data in rows:
                            row_dict = dict(zip(col_names, row_data))
                            
                            if 'record_json' in row_dict and row_dict['record_json']:
                                try:
                                    rj = json.loads(row_dict['record_json'])
                                except Exception:
                                    rj = {}
                                rid = rj.get('resource_id') or row_dict.get('resource_id')
                                origin_sys = row_dict.get('origin_system', '')
                                collection = row_dict.get('collection_name', '')
                                
                                idents = set()
                                for col in ['customer_reference', 'user_id', 'subject_reference', 'email', 'phone', 'email_hash', 'owner_email', 'requester_email']:
                                    if rj.get(col): idents.add(str(rj[col]).lower())
                                    if row_dict.get(col): idents.add(str(row_dict[col]).lower())
                                    
                                sys_id = origin_sys or 'account_service'
                                cat = 'USER_PROFILE'
                                st = 'PRESENT'
                                
                                if origin_sys == 'account_service' or 'profile' in collection:
                                    sys_id = 'account_service'
                                    cat = 'USER_PROFILE'
                                    st = 'PRESENT'
                                elif origin_sys == 'search_service' or 'search' in collection:
                                    sys_id = 'search_service'
                                    cat = 'SEARCH_INDEX_ENTRY'
                                    st = 'PRESENT'
                                elif origin_sys == 'analytics_platform' or 'analytics' in collection:
                                    sys_id = 'analytics_platform'
                                    cat = 'ANALYTICS_PROFILE'
                                    has_pii = any(rj.get(k) for k in ['customer_reference', 'user_id', 'email', 'phone', 'email_hash'])
                                    st = 'PRESENT' if has_pii else 'ANONYMIZED'
                                elif origin_sys == 'support_platform' or 'support' in collection:
                                    sys_id = 'support_platform'
                                    cat = 'SUPPORT_MESSAGE'
                                    msg = str(rj.get('message_excerpt', ''))
                                    has_pii = any(rj.get(k) for k in ['customer_reference', 'requester_email', 'requester_phone'])
                                    st = 'REDACTED' if ('[REDACTED]' in msg or not has_pii) else 'PRESENT'
                                elif origin_sys == 'integration_service' or 'connector' in collection or 'data_flow' in collection:
                                    sys_id = 'integration_service'
                                    cat = 'DATA_FLOW'
                                    enabled = rj.get('enabled')
                                    st = 'ACTIVE' if enabled in [True, 1, 'true', '1'] else 'DISABLED'
                                elif origin_sys == 'backup_service' or 'backup' in collection:
                                    sys_id = 'backup_service'
                                    cat = 'BACKUP_ARCHIVE'
                                    allowed = rj.get('restore_allowed')
                                    st = 'ACTIVE' if allowed in [True, 1, 'true', '1'] else 'BLOCKED'
                                elif origin_sys == 'security_service' or 'security' in collection or 'audit' in collection:
                                    sys_id = 'security_service'
                                    cat = 'SECURITY_AUDIT_LOG'
                                    st = 'PRESENT'
                                elif origin_sys == 'export_service' or 'export' in collection:
                                    sys_id = 'export_service'
                                    cat = 'USER_EXPORT'
                                    st = 'PRESENT'
                                    
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                                    'resource_id': rid, 'category': cat, 'state': st, 'identifiers': idents
                                })
                            else:
                                rid = row_dict.get('resource_id')
                                idents = set()
                                for col in ['customer_reference', 'user_id', 'subject_reference', 'email', 'phone', 'email_hash', 'owner_email', 'requester_email']:
                                    if row_dict.get(col): idents.add(str(row_dict[col]).lower())
                                
                                sys_id = 'account_service'
                                cat = 'USER_PROFILE'
                                st = 'PRESENT'
                                
                                if 'search' in tbl:
                                    sys_id = 'search_service'
                                    cat = 'SEARCH_INDEX_ENTRY'
                                    st = 'PRESENT'
                                elif 'support' in tbl:
                                    sys_id = 'support_platform'
                                    cat = 'SUPPORT_MESSAGE'
                                    msg = str(row_dict.get('message_excerpt', ''))
                                    has_pii = any(row_dict.get(k) for k in ['requester_email', 'requester_phone'])
                                    st = 'REDACTED' if ('[REDACTED]' in msg or not has_pii) else 'PRESENT'
                                elif 'analytics' in tbl:
                                    sys_id = 'analytics_platform'
                                    cat = 'ANALYTICS_PROFILE'
                                    has_pii = any(row_dict.get(k) for k in ['customer_reference', 'user_id', 'email', 'phone', 'email_hash'])
                                    st = 'PRESENT' if has_pii else 'ANONYMIZED'
                                elif 'export' in tbl:
                                    sys_id = 'export_service'
                                    cat = 'USER_EXPORT'
                                    st = 'PRESENT'
                                elif 'connector' in tbl or 'data_flow' in tbl:
                                    sys_id = 'integration_service'
                                    cat = 'DATA_FLOW'
                                    st = 'ACTIVE' if row_dict.get('enabled') in [1, '1', True, 'true'] else 'DISABLED'
                                elif 'backup' in tbl:
                                    sys_id = 'backup_service'
                                    cat = 'BACKUP_ARCHIVE'
                                    st = 'ACTIVE' if row_dict.get('restore_allowed') in [1, '1', True, 'true'] else 'BLOCKED'
                                elif 'security' in tbl:
                                    sys_id = 'security_service'
                                    cat = 'SECURITY_AUDIT_LOG'
                                    st = 'PRESENT'
                                
                                self.observations.append({
                                    'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                                    'resource_id': rid, 'category': cat, 'state': st, 'identifiers': idents
                                })
                except Exception:
                    pass
                finally:
                    conn.close()

            # F. Log files (with trace_id grouping)
            elif ext == '.log':
                traces = {}
                log_lines = []
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                    for line in fp:
                        line = line.strip()
                        if not line: continue
                        log_lines.append(line)
                        
                        data = {}
                        if '{' in line and '}' in line:
                            try:
                                json_str = line[line.find('{'):line.rfind('}')+1]
                                data = json.loads(json_str)
                            except Exception:
                                pass
                        tid = data.get('trace_id')
                        if not tid:
                            m_tid = re.search(r'trace_id[=:]\s*"?([a-zA-Z0-9_-]+)"?', line)
                            if m_tid: tid = m_tid.group(1)
                            
                        if tid:
                            t = traces.setdefault(tid, {'idents': set(), 'resources': set(), 'data': {}})
                            for k in ['subject_ref', 'subject_reference', 'customer_ref', 'customer_reference', 'user_id', 'email', 'lookup_key']:
                                if data.get(k): t['idents'].add(str(data[k]).lower())
                                m_k = re.search(fr'{k}[=:]\s*"?([^\s",]+)"?', line)
                                if m_k: t['idents'].add(m_k.group(1).lower())
                            m_u = re.findall(r'user_[0-9]+', line)
                            for u in m_u: t['idents'].add(u.lower())
                            m_e = re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', line)
                            for e in m_e: t['idents'].add(e.lower())
                            
                            rid = data.get('resource_id')
                            if not rid:
                                m_r = re.search(r'resource_id[=:]\s*"?([a-zA-Z0-9_-]+)"?', line)
                                if m_r: rid = m_r.group(1)
                            if rid:
                                t['resources'].add(rid)
                                t['data'][rid] = {**data, 'line': line}

                # Emit observations from grouped traces
                for tid, t in traces.items():
                    trace_idents = t['idents']
                    for rid, rdata in t['data'].items():
                        line = rdata.get('line', '')
                        line_lower = line.lower()
                        sys_id = 'account_service'
                        cat = 'USER_PROFILE'
                        if rid.startswith('account_'): sys_id, cat = 'account_service', 'USER_PROFILE'
                        elif rid.startswith('search_'): sys_id, cat = 'search_service', 'SEARCH_INDEX_ENTRY'
                        elif rid.startswith('analytics_'): sys_id, cat = 'analytics_platform', 'ANALYTICS_PROFILE'
                        elif rid.startswith('support_'): sys_id, cat = 'support_platform', 'SUPPORT_MESSAGE'
                        elif rid.startswith('export_'): sys_id, cat = 'export_service', 'USER_EXPORT'
                        elif rid.startswith('data_flow_'): sys_id, cat = 'integration_service', 'DATA_FLOW'
                        elif rid.startswith('backup_'): sys_id, cat = 'backup_service', 'BACKUP_ARCHIVE'
                        elif rid.startswith('audit_record_'): sys_id, cat = 'security_service', 'SECURITY_AUDIT_LOG'
                        elif rid.startswith('tombstone_'): sys_id, cat = 'identity_service', 'ACCOUNT_TOMBSTONE'

                        st = 'PRESENT'
                        if 'rows="0"' in line or 'rows=0' in line or 'http_status="404"' in line or 'http_status=404' in line:
                            st = 'ABSENT'
                        elif 'enabled="true"' in line or 'enabled=true' in line:
                            st = 'ACTIVE'
                        elif 'enabled="false"' in line or 'enabled=false' in line:
                            st = 'DISABLED'
                        elif 'deletion_block="false"' in line or 'restore_allowed=true' in line:
                            st = 'ACTIVE'
                        elif 'deletion_block="true"' in line or 'restore_allowed=false' in line:
                            st = 'BLOCKED'
                        elif 'customer_reference=null' in line and 'email=null' in line:
                            st = 'ANONYMIZED'
                        elif '[redacted]' in line_lower:
                            st = 'REDACTED'

                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                            'resource_id': rid, 'category': cat, 'state': st, 'identifiers': set(trace_idents)
                        })

                # Also process non-traced lines
                for line in log_lines:
                    if 'trace_id' in line:
                        continue
                    m_rid = re.search(r'resource_id[=:]\s*"?([a-zA-Z0-9_-]+)"?', line)
                    if m_rid:
                        rid = m_rid.group(1)
                        sys_id = 'account_service'
                        cat = 'USER_PROFILE'
                        if rid.startswith('account_'): sys_id, cat = 'account_service', 'USER_PROFILE'
                        elif rid.startswith('search_'): sys_id, cat = 'search_service', 'SEARCH_INDEX_ENTRY'
                        elif rid.startswith('analytics_'): sys_id, cat = 'analytics_platform', 'ANALYTICS_PROFILE'
                        elif rid.startswith('support_'): sys_id, cat = 'support_platform', 'SUPPORT_MESSAGE'
                        elif rid.startswith('export_'): sys_id, cat = 'export_service', 'USER_EXPORT'
                        elif rid.startswith('data_flow_'): sys_id, cat = 'integration_service', 'DATA_FLOW'
                        elif rid.startswith('backup_'): sys_id, cat = 'backup_service', 'BACKUP_ARCHIVE'
                        elif rid.startswith('audit_record_'): sys_id, cat = 'security_service', 'SECURITY_AUDIT_LOG'
                        elif rid.startswith('tombstone_'): sys_id, cat = 'identity_service', 'ACCOUNT_TOMBSTONE'

                        st = 'PRESENT'
                        if 'rows="0"' in line or 'rows=0' in line or 'http_status="404"' in line or 'http_status=404' in line:
                            st = 'ABSENT'
                        elif 'enabled="true"' in line or 'enabled=true' in line:
                            st = 'ACTIVE'
                        elif 'enabled="false"' in line or 'enabled=false' in line:
                            st = 'DISABLED'
                        elif 'deletion_block="false"' in line or 'restore_allowed=true' in line:
                            st = 'ACTIVE'
                        elif 'deletion_block="true"' in line or 'restore_allowed=false' in line:
                            st = 'BLOCKED'
                        elif 'customer_reference=null' in line and 'email=null' in line:
                            st = 'ANONYMIZED'
                        elif '[redacted]' in line.lower():
                            st = 'REDACTED'
                        
                        idents = set()
                        for u in re.findall(r'user_[0-9]+', line): idents.add(u.lower())
                        for em in re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', line): idents.add(em.lower())

                        self.observations.append({
                            'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                            'resource_id': rid, 'category': cat, 'state': st, 'identifiers': idents
                        })

            # G. Images (PNG)
            elif ext == '.png':
                txt = ocr_cache.get(os.path.basename(fpath), {}).get('full_text', '')
                m_rids = re.findall(r'(account_[0-9]+|search_[0-9]+|analytics_[0-9]+|support_[0-9]+|export_[0-9]+|data_flow_[0-9]+|backup_[0-9]+|audit_record_[0-9]+|tombstone_[0-9]+|marketing_[0-9]+)', txt)
                for rid in set(m_rids):
                    sys_id = 'account_service'
                    cat = 'USER_PROFILE'
                    if rid.startswith('search_'): sys_id, cat = 'search_service', 'SEARCH_INDEX_ENTRY'
                    elif rid.startswith('analytics_'): sys_id, cat = 'analytics_platform', 'ANALYTICS_PROFILE'
                    elif rid.startswith('support_'): sys_id, cat = 'support_platform', 'SUPPORT_MESSAGE'
                    elif rid.startswith('export_'): sys_id, cat = 'export_service', 'USER_EXPORT'
                    elif rid.startswith('data_flow_'): sys_id, cat = 'integration_service', 'DATA_FLOW'
                    elif rid.startswith('backup_'): sys_id, cat = 'backup_service', 'BACKUP_ARCHIVE'
                    elif rid.startswith('audit_record_'): sys_id, cat = 'security_service', 'SECURITY_AUDIT_LOG'
                    elif rid.startswith('tombstone_'): sys_id, cat = 'identity_service', 'ACCOUNT_TOMBSTONE'
                    elif rid.startswith('marketing_'): sys_id, cat = 'marketing_platform', 'MARKETING_PROFILE'

                    st = 'PRESENT'
                    if cat == 'DATA_FLOW': st = 'ACTIVE'
                    elif cat == 'BACKUP_ARCHIVE': st = 'ACTIVE'

                    idents = set()
                    for u in re.findall(r'user_[0-9]+', txt): idents.add(u.lower())
                    for em in re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', txt): idents.add(em.lower())

                    self.observations.append({
                        'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                        'resource_id': rid, 'category': cat, 'state': st, 'identifiers': idents
                    })

            # H. PDFs
            elif ext == '.pdf':
                txt = pdf_cache.get(os.path.basename(fpath), {}).get('full_text', '')
                m_rids = re.findall(r'(account_[0-9]+|search_[0-9]+|analytics_[0-9]+|support_[0-9]+|export_[0-9]+|data_flow_[0-9]+|backup_[0-9]+|audit_record_[0-9]+|tombstone_[0-9]+|marketing_[0-9]+)', txt)
                for rid in set(m_rids):
                    sys_id = 'account_service'
                    cat = 'USER_PROFILE'
                    if rid.startswith('search_'): sys_id, cat = 'search_service', 'SEARCH_INDEX_ENTRY'
                    elif rid.startswith('analytics_'): sys_id, cat = 'analytics_platform', 'ANALYTICS_PROFILE'
                    elif rid.startswith('support_'): sys_id, cat = 'support_platform', 'SUPPORT_MESSAGE'
                    elif rid.startswith('export_'): sys_id, cat = 'export_service', 'USER_EXPORT'
                    elif rid.startswith('data_flow_'): sys_id, cat = 'integration_service', 'DATA_FLOW'
                    elif rid.startswith('backup_'): sys_id, cat = 'backup_service', 'BACKUP_ARCHIVE'
                    elif rid.startswith('audit_record_'): sys_id, cat = 'security_service', 'SECURITY_AUDIT_LOG'
                    
                    if 'delivery_correction' in fpath:
                        cat = 'SUPPORT_ATTACHMENT'

                    idents = set()
                    for u in re.findall(r'user_[0-9]+', txt): idents.add(u.lower())
                    for em in re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', txt): idents.add(em.lower())

                    self.observations.append({
                        'evidence_id': fid, 'captured_at': cap_dt, 'system_id': sys_id,
                        'resource_id': rid, 'category': cat, 'state': 'PRESENT', 'identifiers': idents
                    })
